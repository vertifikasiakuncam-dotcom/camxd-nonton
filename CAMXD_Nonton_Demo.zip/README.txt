CAMXD+ NONTON DEMO

Versi pertama ini belum membutuhkan hosting/database/API.
Cara paling mudah untuk mencoba:
1. Upload folder ini ke layanan hosting statis seperti GitHub Pages atau Cloudflare Pages.
2. Buka index.html melalui alamat situs.
3. Klik Episode 5.
4. Video demo akan muncul di player.

PENTING:
- Video contoh adalah video publik untuk pengujian.
- Untuk versi produksi, ganti URL video dengan video yang kamu miliki/hak tayangnya.
- Setelah versi dasar berhasil, kita bisa lanjutkan ke HLS (.m3u8), database episode, dan signed token.
